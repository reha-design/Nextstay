import{$ as t,s as e,a0 as a}from"./CZkzv59v.js";const i=t((o,r)=>{if(e().isAuthenticated)return a("/")});export{i as default};
